package wemp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import wemp.dao.NgoDaoIntf;

import wemp.model.Ngotable;

@Service("ngoService")
public class NgoServiceImpl implements NgoServiceIntf {

	
	@Autowired
	NgoDaoIntf ngoDao; 
	
	public boolean insertngo(Ngotable ngo) {
		System.out.println("service ngo is called");
		boolean flag=ngoDao.insertngo(ngo);
		return flag;
	
	}

	public List<Ngotable> getNgo() {
		List<Ngotable> list=ngoDao.getNgo();
		return list;
	}

}
