package wemp.service;

import java.util.List;


import wemp.model.Ngotable;
import wemp.model.Training;

public interface NgoServiceIntf {
	public boolean insertngo(Ngotable ngo);
	public List<Ngotable> getNgo();
	
}
