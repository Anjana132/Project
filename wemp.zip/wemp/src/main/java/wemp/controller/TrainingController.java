package wemp.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import wemp.model.Training;
import wemp.service.NgoServiceIntf;
import wemp.service.TrainingServiceIntf;


@Controller("trainingController")
public class TrainingController {

	@Autowired
	TrainingServiceIntf trainingService;
	
	
	
	@RequestMapping(value="/training",method=RequestMethod.POST)
	public ModelAndView inserttraining(HttpServletRequest request,HttpServletResponse response) throws ParseException{
		
		String tname=request.getParameter("tname");
		String tduration=request.getParameter("tduration");
		String ttype=request.getParameter("ttype");
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
		Date sdate=formatter.parse(request.getParameter("sdate")); 
		Date edate=formatter.parse(request.getParameter("edate"));
		Date nbatch=formatter.parse(request.getParameter("nbatch"));
		
		
		Training training = new Training();
		training.setTname(tname);
		training.setTtype(ttype);
		training.setTduration(tduration);
		training.setSdate(sdate);
		training.setEdate(edate);
		training.setNbatch(nbatch);
		
		boolean flag=trainingService.inserttraining(training);
		ModelAndView mav=new ModelAndView();
		mav.addObject("tname",tname);
		if(flag)
			mav.addObject("status","Registration Successful");
		else
			mav.addObject("status","Registration Unsuccessful");
		
		mav.setViewName("NgoRegistered");
		return mav;
		
	}
}
