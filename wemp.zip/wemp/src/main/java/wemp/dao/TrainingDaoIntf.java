package wemp.dao;

import java.util.List;

import wemp.model.Training;

public interface TrainingDaoIntf {

	boolean inserttraining(Training training);

	public List<Training> gettraining();

}
