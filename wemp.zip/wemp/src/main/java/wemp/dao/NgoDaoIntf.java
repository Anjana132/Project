package wemp.dao;

import java.util.List;


import wemp.model.Ngotable;

public interface NgoDaoIntf {

	boolean insertngo(Ngotable ngo);

	public List<Ngotable> getNgo();

	

}
