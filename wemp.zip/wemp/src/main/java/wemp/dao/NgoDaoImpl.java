package wemp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;




import wemp.model.Ngotable;

@Repository("myDao")
public class NgoDaoImpl implements NgoDaoIntf{

	public boolean insertngo(Ngotable ngo) {
		
		boolean result=false;
		
		try{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
			EntityManager em=emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(ngo);
			em.getTransaction().commit();
			System.out.println("dao ngo is called");
            result=true;
            em.close();
            emf.close();
			
		}
		catch(Exception ee){
			System.out.println(ee.getMessage());
		}
		
		return result;
	}
		
	

	public List<Ngotable> getNgo() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
		EntityManager em=emf.createEntityManager();
		@SuppressWarnings("unchecked")
		List<Ngotable> list=em.createQuery("SELECT n FROM ngo n").getResultList();
		System.out.println("dao is called");
		return list;
	}

}
