package com.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.mail.SendMail;
import com.model.Girlboydaycare;
import com.model.Hostel;
import com.model.Ngotable;
import com.model.Sukanya;
import com.model.Training;
import com.model.Users;
import com.model.Workingwomen;
import com.service.UserServiceIntf;

@Controller("myControllerProj")
public class MyControllerUser
{
	@Autowired
	UserServiceIntf myUserService;
	
	 @RequestMapping(value = "/register", method = RequestMethod.GET)
	  public ModelAndView showRegister2() 
	 {
		
	    ModelAndView mav = new ModelAndView("register");
	    mav.addObject("user", new Users());
	    return mav;
	  }
	
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ModelAndView insertUser(HttpServletRequest request,HttpServletResponse response) throws java.text.ParseException,IOException 
	{
	    
		String name = request.getParameter("name");
		String username = request.getParameter("username");
		
		
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		Date date_of_birth = formatter1.parse(request.getParameter("date_of_birth")); 
		
		
		
		String password = request.getParameter("password");
		String email_id = request.getParameter("email_id");
		String contact_number = request.getParameter("contact_number");
		String role = request.getParameter("role");
		
		Users user = new Users();
		user.setName(name);
		user.setUsername(username);
		user.setPassword(password);
		user.setDate_of_birth(date_of_birth);
		user.setEmail_id(email_id);
		user.setContact_number(contact_number);
		user.setRole(role);
	
		boolean flag = myUserService.insertUser(user);
		if(flag)
		{

				ModelAndView mav = new ModelAndView("login");
			    mav.addObject("login", new Users());
			    return mav;
		}
			
		else
		{

			ModelAndView mav = new ModelAndView("register");
	        mav.addObject("user", new Users());
	        mav.addObject("status","Sorry! Registration in incomplete");
	        return mav;
		}
			

		
	}
	
	  @RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView userLogin1(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("user", new Users());
	    return mav;
	  }
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView userLogin2(HttpServletRequest request, HttpServletResponse response, @ModelAttribute Users iuser) throws IOException 
	{
		ModelAndView mav = null;
		Users user = myUserService.userLogin(iuser);
		System.out.println("user:"+user);
	    if (user != null) 
	    {
	    
	   
	      HttpSession session= request.getSession();
	      session.setAttribute("userid", user.getUserid());

	      session.setAttribute("role", user.getRole());
	      System.out.println("role:"+ user.getRole());
	      mav = new ModelAndView();
	      
	      if(user.getRole().equalsIgnoreCase("workingwomen"))
	      {
	    	  mav.setViewName("womenindex");
	      }
	      else if(user.getRole().equalsIgnoreCase("NGO"))
	      {
	    	  mav.setViewName("ngoindex");
	      }
	      else
	      {
	    	  mav.setViewName("adminindex");
	      }
	      
	    } 
	    else
	    {
	      mav = new ModelAndView("login");
	      mav.addObject("message", "Username or Password is wrong!!");
	    }
	    return mav;
	}
	
	@RequestMapping(value = "/changepassword", method = RequestMethod.GET)
	public ModelAndView changepwd1(HttpServletRequest request, HttpServletResponse response) 
	{
	    ModelAndView mav = new ModelAndView("changepassword");
	    return mav;
	}
	  @RequestMapping(value = "/changepassword", method = RequestMethod.POST)
	  public ModelAndView changepwd2(HttpServletRequest request, HttpServletResponse response, HttpSession session)
	  {
	  String username=(String)session.getAttribute("username");
	  String opwd= request.getParameter("opassword");
	  String npwd= request.getParameter("npassword");
	  System.out.println(username+"  "+opwd+"  "+npwd);
	  boolean flag = myUserService.changePassword(username,opwd,npwd);
	  if(flag) 
	  {
	       ModelAndView mav = new ModelAndView("welcome");
	       mav.addObject("message", "Password is successfully updated");
	       return mav;
	  }
	  else 
	  {
		  ModelAndView mav = new ModelAndView("changepassword");
	      mav.addObject("message", "Password is not updated");
	      return mav;
	  }
	}
	  
	  @RequestMapping(value = "/sendmail", method = RequestMethod.POST)
	  public ModelAndView sendmail1(HttpServletRequest request, HttpServletResponse response, HttpSession session, @RequestParam("email") String email)
	  {
		  ModelAndView mav = null;
		  SendMail send = new SendMail();
		  int res = myUserService.checkEmail(email);
		  if(res>0)
		  {
			  boolean flag = send.sendmail(email);
			  if(flag)
			  {	
					mav = new ModelAndView("enterpassword");
			  }
			  else
			  {
 
				  mav = new ModelAndView("forgetpassword");
				  mav.addObject("status", "Try Again");
			  }
 
		  }
		  else
			{
 
			  mav = new ModelAndView("forgetpassword");
			  mav.addObject("status", "Email Id does not exist");
			}
			return mav;

	}
	  
/*	  @RequestMapping(value = "/nsendmail", method = RequestMethod.POST)
	  public ModelAndView sendmail2(HttpServletRequest request, HttpServletResponse response, HttpSession session, @RequestParam("nemail") String email)
	  {
		  ModelAndView mav = null;
		  SendMail send = new SendMail();
		boolean flag = send.sendmail(email);
			  if(flag)
			  {	
					mav = new ModelAndView("enterpassword");
			  }
			  else
			  {
 
				  mav = new ModelAndView("forgetpassword");
				  mav.addObject("status", "Try Again");
			  }
 
	
			return mav;

	}*/
	  
	  
	  @RequestMapping(value = "/forgetpassword", method = RequestMethod.GET)
		public ModelAndView forgetpassword1(HttpServletRequest request, HttpServletResponse response) 
		{
		    ModelAndView mav = new ModelAndView("forgetpassword");
		    return mav;
		}
	  
	  @RequestMapping(value = "/enterpassword", method = RequestMethod.GET)
		public ModelAndView enterpassword1(HttpServletRequest request, HttpServletResponse response) 
		{
		    ModelAndView mav = new ModelAndView("enterpassword");
		    return mav;
		}
	  
	  @RequestMapping(value = "/enterpassword", method = RequestMethod.POST)
		public void enterpassword2(HttpServletRequest request, HttpServletResponse response) 
		{
		  	String email_id = request.getParameter("email_id");
		  	String contact_number = request.getParameter("contact_number");
		  	String password = request.getParameter("password");
		  	myUserService.enterPassword(email_id, contact_number, password);
		}
	  
	  	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
		public ModelAndView welcome(HttpServletRequest request, HttpServletResponse response) 
		{
		    ModelAndView mav = new ModelAndView("welcome");
		    return mav;
		}
	  	
	  	
		/*@RequestMapping(value = "/step", method = RequestMethod.GET)
		public ModelAndView step(HttpServletRequest request, HttpServletResponse response) 
		{
		    ModelAndView mav = new ModelAndView("step");
		    return mav;
		}*/
		
		@RequestMapping(value = "/index", method = RequestMethod.GET)
		public ModelAndView index(HttpServletRequest request, HttpServletResponse response) 
		{
		    ModelAndView mav = new ModelAndView("index");
		    return mav;
		}
		
		@RequestMapping(value = "/logout", method = RequestMethod.GET)
		public ModelAndView userlogout(HttpServletRequest request, HttpServletResponse response) {
			 HttpSession session =request.getSession(false);
			 session.invalidate();
			 ModelAndView mav = new ModelAndView("index");
			 mav.addObject("index", new Users());
			 return mav;
		 }


	  //----------------------------------------------------------------------------------------//
		///Prekshita Controller -----------------//
		@RequestMapping(value="/query",method=RequestMethod.GET)
		public String getQueryform(HttpSession session){
		String username=(String)session.getAttribute("userid");
		 String role=(String)session.getAttribute("role");
		 if(username==null || role==null || role.equalsIgnoreCase("workingwomen")==false){
			 return "login";
		 }
		 else
			return "query";
			 }
		
			
		
			@RequestMapping(value="/query", method=RequestMethod.POST)
			 public ModelAndView addUser2(HttpServletRequest request, HttpServletResponse response,  @ModelAttribute("workingwomen") Workingwomen workingwomen, @RequestParam("file") MultipartFile files[]) throws ParseException{
			//public ModelAndView insertContact(HttpServletRequest request,HttpServletResponse response) throws ParseException{
				String username = request.getParameter("ano");
				for (int i = 0; i < files.length; i++) {
					String filename="";
					if(i==0)
						
						filename=(username+i)+".pdf";
						else if(i==1)
							filename=(username+i)+".pdf";
						else if(i==2)
							filename=(username+i)+".jpg";
					MultipartFile file = files[i];
					try {
						byte[] bytes = file.getBytes();

						// Creating the directory to store file
						String rootPath = System.getProperty("catalina.home");
						File dir = new File(rootPath + File.separator + "tmpFiles");
						if (!dir.exists())
							dir.mkdirs();

						// Create the file on server
						File serverFile = new File(dir.getAbsolutePath()+ File.separator + filename);
						BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
						stream.write(bytes);
						stream.close();
						
						if(i==0)
	                    workingwomen.setAddress_fname(filename);
						else if(i==1)
						workingwomen.setDob_fname(filename);
						else if(i==2)
						workingwomen.setImage(filename);
						
						
						System.out.println("Server File Location="+ serverFile.getAbsolutePath());
						} catch (Exception e) {
						System.out.println( "You failed to upload " + (username+i) + " => " + e.getMessage());
					}
				}
				
			String gender=request.getParameter("gender");
	    	SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-MM-dd");
	    	Date datec=formatter2.parse(request.getParameter("date1"));
			Girlboydaycare gbd=new Girlboydaycare();
			
			gbd.setGender(gender);
			gbd.setDob(datec);
			
			
				
			String name=request.getParameter("name");
			String adhar=request.getParameter("ano");
			String address=request.getParameter("add");
	     	SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-dd");
	    	Date date=formatter1.parse(request.getParameter("date")); 
			String caste=request.getParameter("caste");
			String contact=request.getParameter("contact");
			String phyl=request.getParameter("phychal");
			String ngo=request.getParameter("ngo");
			int workperiod=Integer.parseInt(request.getParameter("wp"));
			
			Double gross=Double.parseDouble(request.getParameter("gi"));
			
			
			Workingwomen ww =new Workingwomen();
			ww.setName(name);
			ww.setAdharno(adhar);
			ww.setAddress(address);
			ww.setDob(date);
			ww.setCaste(caste);
			ww.setContact(contact);
			ww.setPhychal(phyl);
			ww.setNgo(ngo);
			ww.setTrainingperiod(workperiod);
			ww.setGrossIncome(gross);
			ww.setStatus("false");
			ww.getGlist().add(gbd);
			

			
			
			
			boolean flag=myUserService.insertWorkingwomen(ww);
			ModelAndView mav=new ModelAndView();
			mav.addObject("name",name);
		
			if(flag)
				mav.addObject("status","Your details are successfully inserted");
			else
				mav.addObject("status","sorry.........data is not inserted");
			mav.setViewName("viewreport");
			return mav;
			
		}
			
			@RequestMapping(value="/ngotraining",method=RequestMethod.GET)
			public String getNgoTraining(){
				return "ngotraining";

	}
			@RequestMapping(value="/viewusers",method=RequestMethod.GET)
			public ModelAndView ViewUsers(){
				List<Workingwomen> list=myUserService.getUsers();
				ModelAndView mav=new ModelAndView("viewrecord");
				mav.addObject("obj",list);
				return  mav;
			}
			
			@RequestMapping(value="/approve",method=RequestMethod.GET)
			public ModelAndView approvedList(HttpServletRequest request){
				int wid=Integer.parseInt(request.getParameter("wid"));
			
				int res = myUserService.approvedList(wid);	
				ModelAndView mav = new ModelAndView("redirect:/viewusers.do");
				/*mav.addObject("wid", wid);*/
				/*if(res>0)
				{
					mav = new ModelAndView("viewrecord");
					
				}
				else
				{
					mav = new ModelAndView("viewrecord");
				}*/
					return  mav;
			}
			
			@RequestMapping(value="/approvedrecords",method=RequestMethod.GET)
			public ModelAndView approvedrecords(HttpServletRequest request,HttpServletResponse response ){
				//int wid=Integer.parseInt(request.getParameter("wid"));
				
				List<Workingwomen> list=myUserService.approvedrecords();
				
				ModelAndView mav=new ModelAndView("viewapprovedusers");
				mav.addObject("list",list);
					
				
				
				return  mav;
			}
			////////////sheethal
			
			
			@RequestMapping(value="/sukanya",method=RequestMethod.GET)
			public String getQueryform1(HttpSession session){
				String username=(String)session.getAttribute("userid");
				 String role=(String)session.getAttribute("role");
				 if(username==null || role==null || role.equalsIgnoreCase("workingwomen")==false){
					 return "login";
					 
				 }
				 else
				 
				return "sukanya";
			}

			
			@RequestMapping(value="/sukanya1", method=RequestMethod.POST)
			 public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,  @RequestParam("file") MultipartFile files[])throws ParseException{
				Sukanya sukanya = new Sukanya();
				
				String username = request.getParameter("gaadhar");
				for (int i = 0; i < files.length; i++) {
					String filename="";
					if(i==0)
						
						filename=(username+i)+".pdf";
						else if(i==1)
							filename=(username+i)+".pdf";
					MultipartFile file = files[i];
					try {
						byte[] bytes = file.getBytes();

						// Creating the directory to store file
						String rootPath = System.getProperty("catalina.home");
						File dir = new File(rootPath + File.separator + "tmpFiles");
						if (!dir.exists())
							dir.mkdirs();

						// Create the file on server
						File serverFile = new File(dir.getAbsolutePath()+ File.separator + filename);
						BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
						stream.write(bytes);
						stream.close();
						
						if(i==0)
	                    sukanya.setDob_certificate(filename);
						else if(i==1)
							sukanya.setGuardian_aadhar(filename);
						
						
						
						System.out.println("Server File Location="+ serverFile.getAbsolutePath());
						} catch (Exception e) {
						System.out.println( "You failed to upload " + (username+i) + " => " + e.getMessage());
					}
				}
			

				
				String gname = request.getParameter("gname");
				String cname = request.getParameter("cname");
				SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-MM-dd");
				Date udob=formatter2.parse(request.getParameter("udob")); 
				String nationality = request.getParameter("nationality");
				String gaadhar = request.getParameter("gaadhar");
				String address = request.getParameter("address");
				
				Sukanya sukanya3 = new Sukanya();
				sukanya3.setCname(cname);
				sukanya3.setGname(gname);
				sukanya3.setUdob(udob);
				sukanya3.setNationality(nationality);
				sukanya3.setGaadhar(gaadhar);
				sukanya3.setAddress(address);
				boolean flag=myUserService.insertForm(sukanya3);
				System.out.println("Flag:"+flag);
				ModelAndView mav=new ModelAndView();
				mav.addObject("name",gname);
				if(flag)
					mav.addObject("message is accepted");
				else
					mav.addObject("sorry.........message is not accecepted");
				mav.setViewName("viewsukanya");
				return mav;
			}
			
			@RequestMapping(value="/viewsukanya",method=RequestMethod.GET)
			public ModelAndView ViewUser(){
				List<Sukanya> list=myUserService.getUser();
				System.out.println(list.size());
				ModelAndView mav=new ModelAndView("viewsukanyarecord");
				mav.addObject("obj",list);
				return  mav;
			}

			/////anjana----------------------
		
			@RequestMapping(value="/xyz",method=RequestMethod.GET)   // job for NGO - logged
			public String getNgo(HttpSession session){
				 String username=(String)session.getAttribute("userid");
				 String role=(String)session.getAttribute("role");
				 if(username==null || role==null || role.equalsIgnoreCase("ngo")==false){
					 return "login";
				 }
				 else
				 	return "Ngo";

			}
			@RequestMapping(value="/ngo",method=RequestMethod.POST)
			public ModelAndView insertngo(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws ParseException{
				/*Ngotable ngo= new Ngotable();
				
				String username = request.getParameter("ncertificate");
				for (int i = 0; i < files.length; i++) {
					String filename="";
					if(i==0)
					{
						filename=(username+i)+".pdf";
					}
					MultipartFile file = files[i];
					try {
						byte[] bytes = file.getBytes();

						// Creating the directory to store file
						String rootPath = System.getProperty("catalina.home");
						File dir = new File(rootPath + File.separator + "tmpFiles");
						if (!dir.exists())
							dir.mkdirs();

						// Create the file on server
						File serverFile = new File(dir.getAbsolutePath()+ File.separator + filename);
						BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
						stream.write(bytes);
						stream.close();
						
						
						if(i==0)
	                    ngo.setAddress_fname(filename);
						
						
						
						System.out.println("Server File Location="+ serverFile.getAbsolutePath());
						} catch (Exception e) {
						System.out.println( "You failed to upload " + (username+i) + " => " + e.getMessage());
					}
				}*/
				
				System.out.println("controller called");
				String nname=request.getParameter("nname");
				String nman=request.getParameter("nman");
				String nloc=request.getParameter("nloc");
				String nobj=request.getParameter("nobj");
				String contact=request.getParameter("contact");
				
				Ngotable ngo= new Ngotable();
				ngo.setNname(nname);
				ngo.setNman(nman);
				ngo.setNloc(nloc);
				ngo.setNobj(nobj);
				ngo.setContact(contact);
				
				Users  users= new Users();
				String userid=(String)session.getAttribute("userid");
				users.setUserid(userid);
				ngo.setUsers(users);
				
				System.out.println(nobj);
				boolean flag=myUserService.insertngo(ngo);
				ModelAndView mav=new ModelAndView();
				mav.addObject("nname",nname);
				if(flag)
					mav.addObject("status","Registration Successful");
				else
					mav.addObject("status","Registration Unsuccessful");
				
				if(nobj.equals("training"))
						mav.setViewName("training");
				else
						mav.setViewName("hostel");
					
			
				return mav;
				
				
			
			}

			@RequestMapping(value="/training",method=RequestMethod.GET)
			public ModelAndView maketraining(HttpServletRequest request,HttpServletResponse response) throws ParseException{
				ModelAndView mav=new ModelAndView();
				mav.setViewName("training");
				return mav;
				
			}
			
			@RequestMapping(value="/training",method=RequestMethod.POST)
			public ModelAndView inserttraining(HttpServletRequest request,HttpServletResponse response) throws ParseException{
				
				String tname=request.getParameter("tname");
				String tduration=request.getParameter("tduration");
				String ttype=request.getParameter("ttype");
				SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
				Date sdate=formatter.parse(request.getParameter("sdate")); 
				Date edate=formatter.parse(request.getParameter("edate"));
				Date nbatch=formatter.parse(request.getParameter("nbatch"));
				
				
				Training training = new Training();
				training.setTname(tname);
				training.setTtype(ttype);
				training.setTduration(tduration);
				training.setSdate(sdate);
				training.setEdate(edate);
				training.setNbatch(nbatch);
				
				Ngotable ngotable = new Ngotable();
				ngotable.setNid(22); // write from session
				
				training.setNgo(ngotable);
				
				boolean flag=myUserService.inserttraining(training);
				ModelAndView mav=new ModelAndView();
				mav.addObject("tname",tname);
				if(flag)
					mav.addObject("status","Registration Successful");
				else
					mav.addObject("status","Registration Unsuccessful");
				
				mav.setViewName("NgoRegistered");
				return mav;
				
			}
			@RequestMapping(value="/NgoRegistered",method=RequestMethod.GET)
			public ModelAndView ViewUser1(){
				List<Training> list=myUserService.getTraining();
				System.out.println(list.size());
				ModelAndView mav=new ModelAndView("viewtrainingrecord");
				mav.addObject("obj",list);
				return  mav;
			}	
			//hostel
			@RequestMapping(value="/hostel",method=RequestMethod.GET)
			public String getQueryform2(){
				return "hostel";
			}
			@RequestMapping(value="/hostel", method=RequestMethod.POST)
			public ModelAndView insertForm1(HttpServletRequest request,HttpServletResponse response) throws ParseException{
			
			
				String hname = request.getParameter("hname");
				String haddress = request.getParameter("haddress");
				int roomcount = Integer.parseInt(request.getParameter("roomcount"));
				
				Hostel hostel = new Hostel();
				hostel.setHname(hname);
				hostel.setHaddress(haddress);
				hostel.setRoomcount(roomcount);
				boolean flag=myUserService.insertForm(hostel);
				System.out.println("Flag:"+flag);
				ModelAndView mav=new ModelAndView();
				mav.addObject("name",hname);
				if(flag)
					mav.addObject("message is accepted");
				else
					mav.addObject("sorry.........message is not accecepted");
				mav.setViewName("viewhostel");
				return mav;
			}
			
			@RequestMapping(value="/viewhostel",method=RequestMethod.GET)
			public ModelAndView ViewUser2(){
				List<Hostel> list=myUserService.getUserh();
				System.out.println(list.size());
				ModelAndView mav=new ModelAndView("viewhostelrecord");
				mav.addObject("obj",list);
				return  mav;
			}	


				
			
			
			
			
			
			
}
