package com.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.UserDaoIntf;
import com.model.Hostel;
import com.model.Ngotable;
import com.model.Sukanya;
import com.model.Training;
import com.model.Users;
import com.model.Workingwomen;


@Service("myUserService")
public class UserServiceImpl implements UserServiceIntf
{
	@Autowired(required=true)
	UserDaoIntf myUserDao;
	
	/*@Autowired
	UserDaoIntf myDaoUser;*/
	@Transactional
	public boolean insertUser(Users user) 
	{
		
		String uid ="U"+(int)(new Date().getTime());
		user.setUserid(uid);
		boolean flag = myUserDao.insertUser(user);
		
		
		return flag;
	}
	@Transactional
	public Users userLogin(Users user)
	{
		return myUserDao.userLogin(user);
	}
	@Transactional
	public boolean changePassword(String username, String opwd, String npwd) {
		
		return myUserDao.changePassword(username, opwd,  npwd);
	}
	@Transactional
	public void enterPassword(String email_id, String contact_number, String password)
	{
		myUserDao.enterPassword(email_id,contact_number,password);
	}
	
	@Transactional
	public int checkEmail(String email_id) {
		 
		return myUserDao.checkEmail(email_id);
	}
 
	
	
	
	@Transactional
	public boolean insertWorkingwomen(Workingwomen ww) {
		System.out.println("service is called");
		boolean flag=myUserDao.insertWorkingwomen(ww);
		return flag;
	}
	@Transactional
	public List<Workingwomen> getUsers() {
		List<Workingwomen> list=myUserDao.getUsers();
		return list;
		
	}
	@Transactional
	public boolean insertForm(Sukanya sukanya) {
		System.out.println("service called");
		boolean flag=myUserDao.insertForm(sukanya);
		return flag;
	}
	@Transactional
	public List<Sukanya> getUser() {
		
		List<Sukanya> list=myUserDao.getUser();
		return list;
	}
	@Transactional
	public boolean insertngo(Ngotable ngo) {
		System.out.println("service ngo is called");
		boolean flag=myUserDao.insertngo(ngo);
		return flag;
	}
	@Transactional
	public List<Ngotable> getNgo() {
		List<Ngotable> list=myUserDao.getNgo();
		return list;
	}
	@Transactional
	public boolean inserttraining(Training training) {
		System.out.println("service is called");
		boolean flag=myUserDao.inserttraining(training);
		return flag;
	}
	@Transactional
	public List<Training> getTraining() {
		List<Training> list=myUserDao.gettraining();
		return list;
	}
	@Transactional
	public boolean insertForm(Hostel hostel) {
		System.out.println("service called");
		boolean flag=myUserDao.insertForm(hostel);
		return flag;
	}
	@Transactional
	public List<Hostel> getUserh() {
		List<Hostel> list=myUserDao.getUserh();
		return list;
	}
	/*public Workingwomen approvedList(int wid) {
	Workingwomen list=myUserDao.approvedList(wid);
	return list;
	}*/
	@Transactional
	public int approvedList(int wid) {
		int result = myUserDao.approvedList(wid);
		return result;
		
	}
	@Transactional
	public List<Workingwomen> approvedrecords() {
		List<Workingwomen> list=myUserDao.approvedrecords();
		return list;
	}
	
	
}
