/*package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.HostelDaoIntf;
import com.model.Hostel;


@Service("HService")
public class HostelServiceImpl implements HostelServiceIntf {


			@Autowired
			HostelDaoIntf HDao;
			
			public boolean insertForm(Hostel hostel) {
				System.out.println("service called");
				boolean flag=HDao.insertForm(hostel);
				return flag;
			}
			public List<Hostel> getUserh() {
				
				List<Hostel> list=HDao.getUserh();
				return list;
			}
	}


*/