/*package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.SukanyaDaoIntf;
import com.model.Sukanya;


@Service("SService")
public class SukanyaServiceImpl implements SukanyaServiceIntf {
		@Autowired
		SukanyaDaoIntf SDao;
		
		public boolean insertForm(Sukanya sukanya) {
			System.out.println("service called");
			boolean flag=SDao.insertForm(sukanya);
			return flag;
		}
		public List<Sukanya> getUser() {
			
			List<Sukanya> list=SDao.getUser();
			return list;
		}
}
*/