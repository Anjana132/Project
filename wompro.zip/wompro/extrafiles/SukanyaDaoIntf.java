/*package com.dao;

import java.util.List;

import com.model.Sukanya;



public interface SukanyaDaoIntf {
	public boolean insertForm(Sukanya sukanya);
	public List<Sukanya> getUser();
}
*/