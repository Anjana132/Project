/*package com.service;

import java.util.List;

import com.model.Ngotable;

public interface NgoServiceIntf {
	public boolean insertngo(Ngotable ngo);
	public List<Ngotable> getNgo();
}
*/